package com.cts.fms.feedbackmanagement.repository;

import com.cts.fms.feedbackmanagement.domain.FeedbackQuestion;

public class UserEventRegistrationDetail {

	public FeedbackQuestion getUserStatusType() {
		// TODO Auto-generated method stub
		return null;
	}

}
