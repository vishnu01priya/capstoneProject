package com.cts.fms.feedbackmanagement.repository;

import com.cts.fms.feedbackmanagement.domain.User;

public class UserEventRegistrationDetailRepository {

	public UserEventRegistrationDetail findByUser(User user) {
		// TODO Auto-generated method stub
		return null;
	}

}
