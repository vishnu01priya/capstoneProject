package com.cts.fms.feedbackmanagement.domain;

public class FeedbackAttempt {



}
