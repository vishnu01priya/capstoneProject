package com.cts.fms.feedbackmanagement.repository;

import com.cts.fms.feedbackmanagement.domain.UserStatusType;

public class UserStatusTypeRepository {

	public UserStatusType findByName(String name) {
		// TODO Auto-generated method stub
		return null;
	}

}
