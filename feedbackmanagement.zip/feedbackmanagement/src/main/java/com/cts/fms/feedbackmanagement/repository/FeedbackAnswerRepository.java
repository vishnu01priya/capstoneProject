package com.cts.fms.feedbackmanagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;

public interface FeedbackAnswerRepository extends JpaRepository {
}
