package com.cts.fms.feedbackmanagement.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.fms.feedbackmanagement.domain.FeedbackQuestion;
import com.cts.fms.feedbackmanagement.domain.UserStatusType;

public interface FeedbackQuestionRepository extends JpaRepository {

	FeedbackQuestion findByName(String name);

	List<FeedbackQuestion> findByFeedbackType(String feedbackType);

	List<FeedbackQuestion> findByUserStatusType(UserStatusType userStatusTypeIns);
}
