package com.cts.fms.usermanagement.repository;

import com.cts.fms.usermanagement.domain.User;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import reactor.core.publisher.Flux;

public interface UserRepository extends ReactiveCrudRepository<User,Long> {


}
