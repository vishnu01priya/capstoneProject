package com.cts.fms.usermanagement.controller;

import com.cts.fms.usermanagement.domain.User;
import com.cts.fms.usermanagement.domain.UserStatusType;
import com.cts.fms.usermanagement.repository.RoleRepository;
import com.cts.fms.usermanagement.repository.UserRepository;
import com.cts.fms.usermanagement.repository.UserStatusTypeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;
import reactor.core.publisher.Mono;

import static org.springframework.web.reactive.function.server.ServerResponse.ok;

@Component
public class UserController {

    @Autowired
    UserRepository userRepository;

    @Autowired
    UserStatusTypeRepository userStatusTypeRepository;

    @Autowired
    RoleRepository roleRepository;


    public Mono<ServerResponse> listUser(ServerRequest request) {
        return ok()
                .contentType(MediaType.APPLICATION_JSON)
                .body(userRepository.findAll(), User.class);
    }

    public Mono<ServerResponse> listUserStatusType(ServerRequest request) {
        return ok()
                .contentType(MediaType.APPLICATION_JSON)
                .body(userStatusTypeRepository.findAll(), UserStatusType.class);

    }

}
