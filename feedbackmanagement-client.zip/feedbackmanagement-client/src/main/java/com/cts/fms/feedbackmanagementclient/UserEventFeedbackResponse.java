package com.cts.fms.feedbackmanagementclient;

public class UserEventFeedbackResponse {

}
