package com.cts.fms.eventmanagement.controller;

import com.cts.fms.eventmanagement.domain.Dashboard;
import com.cts.fms.eventmanagement.domain.Event;
import com.cts.fms.eventmanagement.domain.Role;
import com.cts.fms.eventmanagement.domain.User;
import com.cts.fms.eventmanagement.exporter.ExcelFileExporter;
import com.cts.fms.eventmanagement.repository.EventRepository;
import com.cts.fms.eventmanagement.repository.RoleRepository;
import com.cts.fms.eventmanagement.repository.UserRepository;
import org.apache.commons.compress.utils.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.stream.IntStream;

@RestController
@RequestMapping("/event/api/v1/")
public class EventController {

    @Autowired
    EventRepository eventRepository;

    @Autowired
    UserRepository userRepository;

    @Autowired
    RoleRepository roleRepository;

    @GetMapping("/listAll")
    public List<Event> eventList() {
        return eventRepository.findAll();
    }

    @PostMapping("/findEventByUser")
    public List<Event> findEventByUser(@RequestBody User userIns) {
        User poc = userRepository.findByUsername(userIns.getUsername());
        List<Event> eventList = eventRepository.findByPoc(poc);
        return eventList;
    }

    @GetMapping("/findByEventId/{eventId}")
    public Event findById(@PathVariable String eventId) {
        System.out.println("eventId"+eventId);
        Event eventIns = eventRepository.findByEventId(eventId);
        System.out.println("eventIns"+eventIns);
        return eventIns;
    }

    @GetMapping("/dashboard")
    public Dashboard dashboard() {
        List<Event> eventList = eventRepository.findAll();
        int totalEvents = eventList.size();
        int livesImpacted = eventList.stream().mapToInt(x -> Integer.parseInt(x.getLivesImpacted())).sum();
        int totalVolunteer = eventList.stream().mapToInt(x -> Integer.parseInt(x.getTotalVolunteer())).sum();
        int totalParticipants = eventList.stream().mapToInt(x -> x.getUserEventFeedbackResponseList().size()).sum();
        Dashboard dashboardIns = new Dashboard(totalEvents,livesImpacted,totalVolunteer,totalParticipants);
        return dashboardIns;
    }

    @PostMapping("/pocDashboard")
    public Dashboard pocDashboard(@RequestBody Map<String,String> params) {

        String username = params.get("username");
        User poc = userRepository.findByUsername(username);
        System.out.println("poc id "+poc.getId());
        List<Event> eventList = eventRepository.findByPoc(poc);

        int totalEvents = eventList.size();
        int livesImpacted = eventList.stream().mapToInt(x -> Integer.parseInt(x.getLivesImpacted())).sum();
        int totalVolunteer = eventList.stream().mapToInt(x -> Integer.parseInt(x.getTotalVolunteer())).sum();
        int totalParticipants = eventList.stream().mapToInt(x -> x.getUserEventFeedbackResponseList().size()).sum();
        Dashboard dashboardIns = new Dashboard(totalEvents,livesImpacted,totalVolunteer,totalParticipants);

        return dashboardIns;

    }

    @PostMapping("/download/report.xlsx")
    public void downloadCsv(HttpServletResponse response,@RequestBody Map<String,String> params) throws IOException {
        response.setContentType("application/octet-stream");
        response.setHeader("Content-Disposition", "attachment; filename=report.xlsx");
        String username = params.get("username");
        User poc = userRepository.findByUsername(username);
        List<Event> eventList = null;
        if(poc.getRole().getName().equals("admin")) {
            eventList = eventRepository.findAll();
        } else {
            eventList = eventRepository.findByPoc(poc);
        }
        System.out.println("poc id "+poc.getId());
        ByteArrayInputStream stream = ExcelFileExporter.contactListToExcelFile(eventList);
        IOUtils.copy(stream, response.getOutputStream());
    }

}
