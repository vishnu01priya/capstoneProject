package com.cts.fms.emailservice.repository;

import com.cts.fms.emailservice.domain.Email;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EmailRepository extends JpaRepository<Email,Long> {

}
