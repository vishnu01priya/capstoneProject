package com.cts.fms.emailservice.service;

import com.cts.fms.emailservice.domain.Email;
import com.cts.fms.emailservice.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

@Service
public class EmailService {

    private JavaMailSender javaMailSender;

    private UserRepository userRepository;

    @Autowired
    public EmailService(JavaMailSender javaMailSender,UserRepository userRepository) {
        this.javaMailSender = javaMailSender;
        this.userRepository = userRepository;
    }

    @Async
    public Boolean send(Email email) throws MailException, InterruptedException {
        SimpleMailMessage simpleMailMessage = new SimpleMailMessage();
        simpleMailMessage.setFrom(email.getFrom());
        simpleMailMessage.setTo(email.getTo());
        simpleMailMessage.setSubject(email.getSubject());
        simpleMailMessage.setText(email.getText());
        System.out.println(javaMailSender);
        javaMailSender.send(simpleMailMessage);

        return  Boolean.TRUE;
    }



}
