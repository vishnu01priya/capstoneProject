package com.cts.fms.emailservice.repository;

import com.cts.fms.emailservice.domain.Role;
import com.cts.fms.emailservice.domain.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface UserRepository extends JpaRepository<User,Long> {

    public User findByEmail(String email);

    public List<User> findByRole(Role role);


}
