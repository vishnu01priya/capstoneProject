package com.cts.fms.emailservice.repository;

import java.util.List;

import com.cts.fms.emailservice.domain.Event;
import com.cts.fms.emailservice.domain.UserEventRegistrationDetail;

public class UserEventRegistrationDetailRepository {

	public List<UserEventRegistrationDetail> findByEvent(Event eventIns) {
		// TODO Auto-generated method stub
		return null;
	}

}
