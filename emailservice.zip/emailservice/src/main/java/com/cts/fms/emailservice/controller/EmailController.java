package com.cts.fms.emailservice.controller;

import com.cts.fms.emailservice.domain.*;
import com.cts.fms.emailservice.repository.EventRepository;
import com.cts.fms.emailservice.repository.RoleRepository;
import com.cts.fms.emailservice.repository.UserEventRegistrationDetailRepository;
import com.cts.fms.emailservice.repository.UserRepository;
import com.cts.fms.emailservice.service.EmailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/email/api/v1")
public class EmailController {

    private EmailService emailService;

    private UserRepository userRepository;

    private RoleRepository roleRepository;

    private UserEventRegistrationDetailRepository userEventRegistrationDetailRepository;

    private EventRepository eventRepository;

    @Autowired
    public EmailController(EmailService emailService, UserRepository userRepository, RoleRepository roleRepository, UserEventRegistrationDetailRepository userEventRegistrationDetailRepository, EventRepository eventRepository) {
        this.emailService = emailService;
        this.userRepository = userRepository;
        this.roleRepository = roleRepository;
        this.userEventRegistrationDetailRepository = userEventRegistrationDetailRepository;
        this.eventRepository = eventRepository;
    }

    @GetMapping("/sendEmail")
    public Boolean sendEmail()  {
        Email email = new Email();
        email.setFrom("cramarnath@gmail.com");
        email.setSubject("Event Feedback");
        email.setText("Hi Participants, we kindly request you to provide valuable feedback by clicking below link");
        Role roleIns = roleRepository.findByName("participant");
        List<User> userList = (List<User>) userRepository.findByRole(roleIns);
        List<String> emailList = userList.stream().filter(user -> user.getEmail() != null).map(User::getEmail).collect(Collectors.toList());
        String[] emailArray = emailList.stream().toArray(String[]::new);
        System.out.println("emailList"+emailArray[0]);
        email.setTo(emailArray);
        //String[] emailArray = (String[]) emailList.toArray();
        //userRepository.findAll().
        try {
            emailService.send(email);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return Boolean.TRUE;
    }

    @GetMapping("/sendEventEmail/{eventId}")
    public Boolean sendEventEmail(@PathVariable String eventId)  {
        Email email = new Email();
        email.setFrom("cramarnath@gmail.com");
        email.setSubject("Event Feedback");
        email.setText("Hi Participants, we kindly request you to provide valuable feedback by clicking below link");
        Event eventIns = eventRepository.findByEventId(eventId);
        List<UserEventRegistrationDetail> userEventRegistrationDetailList = userEventRegistrationDetailRepository.findByEvent(eventIns);
        List<User> userList = userEventRegistrationDetailList.stream().filter(userEventRegistrationDetail -> userEventRegistrationDetail.getUser().getEmail() != null).map(UserEventRegistrationDetail::getUser).collect(Collectors.toList());
        List<String> emailList = userList.stream().filter(user -> user.getEmail() != null).map(User::getEmail).collect(Collectors.toList());
        String[] emailArray = emailList.stream().toArray(String[]::new);
        System.out.println("emailList"+emailArray[0]);
        email.setTo(emailArray);
        try {
            emailService.send(email);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return Boolean.TRUE;
    }

}
