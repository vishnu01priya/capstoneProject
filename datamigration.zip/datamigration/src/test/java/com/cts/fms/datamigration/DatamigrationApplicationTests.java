package com.cts.fms.datamigration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DatamigrationApplicationTests {

	@Test
	void contextLoads() {
	}

}
