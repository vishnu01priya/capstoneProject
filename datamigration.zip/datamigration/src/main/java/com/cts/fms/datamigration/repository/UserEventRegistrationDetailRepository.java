package com.cts.fms.datamigration.repository;

import com.cts.fms.datamigration.domain.Event;
import com.cts.fms.datamigration.domain.User;
import com.cts.fms.datamigration.domain.UserEventRegistrationDetail;

public class UserEventRegistrationDetailRepository {

	public UserEventRegistrationDetail findByUserAndEvent(User userIns, Event eventIns) {
		// TODO Auto-generated method stub
		return null;
	}

	public void save(UserEventRegistrationDetail userEventRegistrationDetailIns) {
		// TODO Auto-generated method stub
		
	}

}
