-- MySQL dump 10.13  Distrib 5.7.17, for macos10.12 (x86_64)
--
-- Host: 127.0.0.1    Database: fms
-- ------------------------------------------------------
-- Server version	5.7.25

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `email`
--

DROP TABLE IF EXISTS `email`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `email` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `from` varchar(45) NOT NULL,
  `to` varchar(45) NOT NULL,
  `cc` varchar(45) DEFAULT NULL,
  `bcc` varchar(45) DEFAULT NULL,
  `subject` varchar(45) DEFAULT NULL,
  `text` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email`
--

LOCK TABLES `email` WRITE;
/*!40000 ALTER TABLE `email` DISABLE KEYS */;
/*!40000 ALTER TABLE `email` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event`
--

DROP TABLE IF EXISTS `event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event` (
  `id` bigint(20) NOT NULL,
  `activity_type` varchar(255) DEFAULT NULL,
  `base_location` varchar(255) DEFAULT NULL,
  `beneficiary_name` varchar(255) DEFAULT NULL,
  `business_unit` varchar(255) DEFAULT NULL,
  `category` varchar(255) DEFAULT NULL,
  `council_name` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `event_id` varchar(255) DEFAULT NULL,
  `lives_impacted` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `overall_volunter_hour` varchar(255) DEFAULT NULL,
  `project_name` varchar(255) DEFAULT NULL,
  `start_date` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `total_travel_hour` varchar(255) DEFAULT NULL,
  `total_volunteer` varchar(255) DEFAULT NULL,
  `total_volunteer_hour` varchar(255) DEFAULT NULL,
  `venue_address` varchar(255) DEFAULT NULL,
  `poc_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKmj63p6odf2laqgj0mo4xtippi` (`poc_id`),
  CONSTRAINT `FKmj63p6odf2laqgj0mo4xtippi` FOREIGN KEY (`poc_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event`
--

LOCK TABLES `event` WRITE;
/*!40000 ALTER TABLE `event` DISABLE KEYS */;
INSERT INTO `event` VALUES (2,'1','Singapore','KWONG WAI SHIU HOSPITAL',NULL,'Essentials or relief','Outreach Singapore','Thank you for all your donations of food items to make this a good Xmas for everyone! Come be a Santa and distribute these Bags of Joy to elderly low income residents in Central Singapore and feel the joy of giving!\n\nFriends and family welcome!','EVNT00047261','800','Bags of Joy Distribution','130','Donation or Distribution','15-12-18','Approved','42','21','88','705, Serangoon Road, Singapore, Singapore, Singapore-328127',1),(4,'3','Chennai','Kamarajar Illam,Tambaram',NULL,'Multiple Subjects','Chennai BFS Outreach','Teach various subjects to the students in Kamarajar Illam','EVNT00046103','30','Be a Teacher @ Kamarajar Illam','42','Be a Teacher','01-12-18','Approved','14','14','28','Gandhi Rd, Ranganathapuram, Tambaram, Tambaram, , , India-600045',3),(6,'3','United Kingdom','St. Edward’s CE Voluntary Aided Primary School',NULL,'Other Community Programs','Outreach UK','The school is hosting a Christmas Fayre to raise money to refurbish their swimming pool that is used by the children in the local community. Volunteers needed to set up, run and pack up the stalls. Can make it a fun day with your family.','EVNT00046385','0','1st Dec PM-Christmas fair to save a school swimming pool','24','Community Program','01-12-18','Approved','0','4','24','Havering Drive, Havering Drive, , , Romford-RM1 4BT',5),(8,'4','Pune','Gurukulam',NULL,'Other Subject','Pune QEA LBG Outreach','There is a lack of co-ordination in between the students and no friendly relation to each other.  Through good talk, learning game we will improve co-ordination in between the students.','EVNT00046530','20','Improve in Co-ordination','5','Be a Teacher','01-12-18','Approved','0','2','5','Krantiveer Chapekar Smarak Samitee, Opposite Ram Mandir, Chinchwad Gaon, Pune, Maharashtra, India-411033',7),(10,'4','Pune','Gurukulam',NULL,'Other Subject','Pune QEA LBG Outreach','There is a lack of co-ordination in between the students and no friendly relation to each other.  Through good talk, learning game we will improve co-ordination in between the students.','EVNT00046531','2','Improve in Co-ordination','4','Be a Teacher','08-12-18','Approved','0','2','4','Krantiveer Chapekar Smarak Samitee, Opposite Ram Mandir, Chinchwad Gaon, Pune, Maharashtra, India-411033',9),(12,'4','Chennai','ADW Primary school chitlapakkam',NULL,'English','Chennai BPS Outreach','BAT','EVNT00046588','2','BAT','4','Be a Teacher','03-12-18','Approved','0','2','4','Chitlapakkam, , , India-600064',11),(14,'3','Coimbatore','Panchayat Union Primary School, Keeranatham Puthupalayam',NULL,'Multiple Subjects','Coimbatore Outreach','Teaches English Grammar','EVNT00046611','22','TEACHING','12.5','Be a Teacher','13-12-18','Approved','2.5','5','10','Keeranatham Puthupalayam, Coimbatore, Tamil nadu, India-641035',13),(16,'5','Chennai','Panchayat Union Primary School, Amman Nagar',NULL,'English','Chennai RCG Outreach','To teach \'english\' (mainly spellings) to \'D\' Category students of 4th std students (A and B section).','EVNT00047114','1','Be a Teacher','9.6','Be a Teacher','04-12-18','Approved','9','6','0.6','Amman Nagar, Trisulam, Chennai, Tamil Nadu, India-600043',15);
/*!40000 ALTER TABLE `event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_user_event_feedback_response_list`
--

DROP TABLE IF EXISTS `event_user_event_feedback_response_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_user_event_feedback_response_list` (
  `event_id` bigint(20) NOT NULL,
  `user_event_feedback_response_list_id` bigint(20) NOT NULL,
  UNIQUE KEY `UK_f5kqvfahrdy4vpxu5k96ipynj` (`user_event_feedback_response_list_id`),
  KEY `FKcph55vl48mvujs747j7in3u4y` (`event_id`),
  CONSTRAINT `FKclrdki6332wlhxrn7mltu5gr2` FOREIGN KEY (`user_event_feedback_response_list_id`) REFERENCES `user_event_feedback_response` (`id`),
  CONSTRAINT `FKcph55vl48mvujs747j7in3u4y` FOREIGN KEY (`event_id`) REFERENCES `event` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_user_event_feedback_response_list`
--

LOCK TABLES `event_user_event_feedback_response_list` WRITE;
/*!40000 ALTER TABLE `event_user_event_feedback_response_list` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_user_event_feedback_response_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `feedback_answer`
--

DROP TABLE IF EXISTS `feedback_answer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `feedback_answer` (
  `id` bigint(20) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feedback_answer`
--

LOCK TABLES `feedback_answer` WRITE;
/*!40000 ALTER TABLE `feedback_answer` DISABLE KEYS */;
INSERT INTO `feedback_answer` VALUES (1,'Unexpected Personal Committment','Unexpected Personal Committment'),(2,'Unexpected Official Work','Unexpected Official Work'),(3,'Event not What I Expected','Event not What I Expected'),(4,'Did Not Receive Further Information About The Event','Did Not Receive Further Information About The Event'),(5,'Incorrectly Registered','Incorrectly Registered'),(6,'Do Not Wish to Disclose','Do Not Wish to Disclose'),(129,'Test123','Test123'),(130,'Test123','Test123'),(131,'Test123','Test123'),(132,'Test321','Test321'),(133,'123','123'),(134,'123','123'),(135,'Do Not Wish to Disclose','Do Not Wish to Disclose'),(136,'Unexpected Personal Committment','Unexpected Personal Committment'),(137,'Event Not What I Expected','Event Not What I Expected'),(138,'Did Not Receive Further Information About The Event','Did Not Receive Further Information About The Event'),(139,'Incorrectly Registered','Incorrectly Registered'),(140,'Test123','Test123'),(141,'Amar','Amar'),(142,'Unit Testing','Unit Testing'),(143,'Unit Testing2','Unit Testing2'),(144,'Unit Testing3','Unit Testing3');
/*!40000 ALTER TABLE `feedback_answer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `feedback_question`
--

DROP TABLE IF EXISTS `feedback_question`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `feedback_question` (
  `id` bigint(20) NOT NULL,
  `description` text,
  `name` varchar(255) DEFAULT NULL,
  `user_status_type_id` bigint(20) DEFAULT NULL,
  `feedback_type` varchar(255) DEFAULT NULL,
  `feedback_type_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKqo4pb0xtm29c02ibpr9h5pa34` (`user_status_type_id`),
  KEY `FKc7g1qceg0vu71r9f6mcar4kby` (`feedback_type_id`),
  CONSTRAINT `FKc7g1qceg0vu71r9f6mcar4kby` FOREIGN KEY (`feedback_type_id`) REFERENCES `feedback_type` (`id`),
  CONSTRAINT `FKqo4pb0xtm29c02ibpr9h5pa34` FOREIGN KEY (`user_status_type_id`) REFERENCES `user_status_type` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feedback_question`
--

LOCK TABLES `feedback_question` WRITE;
/*!40000 ALTER TABLE `feedback_question` DISABLE KEYS */;
INSERT INTO `feedback_question` VALUES (0,'Hey there, you had registered for the event on saturday. we would like to know the reason for not joining the event to understand if the team which created the event has some room for improvement in their process, so that we get 100% participation from the registered attendees.','Hey there, you had registered for the event on saturday. we would like to know the reason for not joining the event',2,'Single Answer',NULL),(1,'Hey there please share your feedback for unregistered from the event?','Hey there please share your feedback for unregistered from the event?',3,'Single Answer',NULL),(2,'What did you like about this volunteering activity?','What did you like about this volunteering activity?',1,'Free Text Answer',NULL),(3,'What can be improved in this volunteering activity?','What can be improved in this volunteering activity?',1,'Free Text Answer',NULL);
/*!40000 ALTER TABLE `feedback_question` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `feedback_question_feedback_answer_list`
--

DROP TABLE IF EXISTS `feedback_question_feedback_answer_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `feedback_question_feedback_answer_list` (
  `feedback_question_id` bigint(20) NOT NULL,
  `feedback_answer_list_id` bigint(20) NOT NULL,
  UNIQUE KEY `UK_7yl8p8isdltnlc40c6v19lhyg` (`feedback_answer_list_id`),
  KEY `FKkawa2qh5oq3oqlb7mn38aau0p` (`feedback_question_id`),
  CONSTRAINT `FKkawa2qh5oq3oqlb7mn38aau0p` FOREIGN KEY (`feedback_question_id`) REFERENCES `feedback_question` (`id`),
  CONSTRAINT `FKoy0i5piqry3jppophl7fr1gil` FOREIGN KEY (`feedback_answer_list_id`) REFERENCES `feedback_answer` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feedback_question_feedback_answer_list`
--

LOCK TABLES `feedback_question_feedback_answer_list` WRITE;
/*!40000 ALTER TABLE `feedback_question_feedback_answer_list` DISABLE KEYS */;
INSERT INTO `feedback_question_feedback_answer_list` VALUES (0,135),(0,136),(0,137),(0,138),(0,139),(1,1),(1,2),(1,3),(1,4),(1,142),(1,143);
/*!40000 ALTER TABLE `feedback_question_feedback_answer_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `feedback_type`
--

DROP TABLE IF EXISTS `feedback_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `feedback_type` (
  `id` bigint(20) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feedback_type`
--

LOCK TABLES `feedback_type` WRITE;
/*!40000 ALTER TABLE `feedback_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `feedback_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hibernate_sequence`
--

DROP TABLE IF EXISTS `hibernate_sequence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hibernate_sequence` (
  `next_val` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hibernate_sequence`
--

LOCK TABLES `hibernate_sequence` WRITE;
/*!40000 ALTER TABLE `hibernate_sequence` DISABLE KEYS */;
INSERT INTO `hibernate_sequence` VALUES (145),(145),(145),(145),(145),(145),(145),(145),(145);
/*!40000 ALTER TABLE `hibernate_sequence` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role` (
  `id` bigint(20) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role`
--

LOCK TABLES `role` WRITE;
/*!40000 ALTER TABLE `role` DISABLE KEYS */;
INSERT INTO `role` VALUES (1,'admin','admin'),(2,'pmo','pmo'),(3,'poc','poc'),(4,'participant','participant');
/*!40000 ALTER TABLE `role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` bigint(20) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `mobile` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `role_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKn82ha3ccdebhokx3a8fgdqeyy` (`role_id`),
  CONSTRAINT `FKn82ha3ccdebhokx3a8fgdqeyy` FOREIGN KEY (`role_id`) REFERENCES `role` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,NULL,'7200762700','568912',NULL,'568912',3),(3,NULL,'7200762701','568913',NULL,'568913',3),(5,NULL,'7200762701','568914',NULL,'568914',3),(7,NULL,'7200762701','568915',NULL,'568915',3),(9,NULL,'7200762701','testpoc',NULL,'testpoc',3),(11,NULL,'7200762701','568917',NULL,'568917',3),(13,NULL,'7200762701','568918',NULL,'568918',3),(15,NULL,'7200762701','568919',NULL,'568919',3),(17,'amarnath.c.ramakrishnan@gmail.com',NULL,'testassociate','testassociate','testassociate',4),(18,'cramarnath@icloud.com',NULL,'testassociate2','testassociate2','testassociate2',4),(19,'cramarnath@gmail.com',NULL,'testassociate3','testassociate3','testassociate3',4),(20,NULL,NULL,'Name 4','897654','897654',4),(21,NULL,NULL,'Name 5','897655','897655',4),(22,NULL,NULL,'Name 6','897656','897656',4),(23,NULL,NULL,'Name 7','897657','897657',4),(24,NULL,NULL,'Name 8','897658','897658',4),(25,NULL,NULL,'Name 9','897659','897659',4),(26,NULL,NULL,'Name 10','897660','897660',4),(27,NULL,NULL,'Name 11','897661','897661',4),(28,NULL,NULL,'Name 12','897662','897662',4),(29,NULL,NULL,'Name 13','897663','897663',4),(30,NULL,NULL,'Name 14','897664','897664',4),(31,NULL,NULL,'Name 15','897665','897665',4),(32,NULL,NULL,'Name 16','897666','897666',4),(33,NULL,NULL,'Name 17','897667','897667',4),(34,NULL,NULL,'Name 18','897668','897668',4),(35,NULL,NULL,'Name 19','897669','897669',4),(36,NULL,NULL,'Name 20','897670','897670',4),(37,NULL,NULL,'Name 21','897671','897671',4),(38,NULL,NULL,'Name 22','897672','897672',4),(39,NULL,NULL,'Name 23','897673','897673',4),(40,NULL,NULL,'Name 24','897674','897674',4),(41,NULL,NULL,'Name 25','897675','897675',4),(42,NULL,NULL,'Name 26','897676','897676',4),(43,NULL,NULL,'Name 27','897677','897677',4),(44,NULL,NULL,'Name 28','897678','897678',4),(45,NULL,NULL,'Name 29','897679','897679',4),(46,NULL,NULL,'Name 30','897680','897680',4),(47,NULL,NULL,'Name 31','897681','897681',4),(48,NULL,NULL,'Name 32','897682','897682',4),(49,NULL,NULL,'Name 33','897683','897683',4),(50,NULL,NULL,'Name 34','897684','897684',4),(51,NULL,NULL,'Name 35','897685','897685',4),(52,NULL,NULL,'Name 36','897686','897686',4),(53,NULL,NULL,'Name 37','897687','897687',4),(54,NULL,NULL,'Name 38','897688','897688',4),(55,NULL,NULL,'Name 39','897689','897689',4),(56,NULL,NULL,'Name 40','897690','897690',4),(57,NULL,NULL,'Name 41','897691','897691',4),(58,NULL,NULL,'Name 42','897692','897692',4),(59,NULL,NULL,'Name 43','897693','897693',4),(60,NULL,NULL,'Name 44','897694','897694',4),(61,NULL,NULL,'Name 45','897695','897695',4),(62,NULL,NULL,'Name 46','897696','897696',4),(63,NULL,NULL,'Name 47','897697','897697',4),(64,NULL,NULL,'Name 48','897698','897698',4),(65,NULL,NULL,'Name 49','897699','897699',4),(66,NULL,NULL,'Name 50','897700','897700',4),(67,NULL,NULL,'Name 51','897701','897701',4),(68,NULL,NULL,'Name 52','897702','897702',4),(69,NULL,NULL,'Name 53','897703','897703',4),(70,NULL,NULL,'Name 54','897704','897704',4),(71,NULL,NULL,'Name 55','897705','897705',4),(72,NULL,NULL,'Name 56','897706','897706',4),(73,'amar@a.com',NULL,'amar','amar','amar',1);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_event_feedback_response`
--

DROP TABLE IF EXISTS `user_event_feedback_response`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_event_feedback_response` (
  `id` bigint(20) NOT NULL,
  `overall_rating` double DEFAULT NULL,
  `event_id` bigint(20) DEFAULT NULL,
  `participant_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKptn0a9gj2dxaafupbb33u70dr` (`event_id`),
  KEY `FKrlmxyf3fmeo9lbmiqbtgqlo35` (`participant_id`),
  CONSTRAINT `FKptn0a9gj2dxaafupbb33u70dr` FOREIGN KEY (`event_id`) REFERENCES `event` (`id`),
  CONSTRAINT `FKrlmxyf3fmeo9lbmiqbtgqlo35` FOREIGN KEY (`participant_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_event_feedback_response`
--

LOCK TABLES `user_event_feedback_response` WRITE;
/*!40000 ALTER TABLE `user_event_feedback_response` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_event_feedback_response` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_event_feedback_response_feedback_question_list`
--

DROP TABLE IF EXISTS `user_event_feedback_response_feedback_question_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_event_feedback_response_feedback_question_list` (
  `user_event_feedback_response_id` bigint(20) NOT NULL,
  `feedback_question_list_id` bigint(20) NOT NULL,
  UNIQUE KEY `UK_lfin6dk61fpo6va7xcwu3ob97` (`feedback_question_list_id`),
  KEY `FKdlh2lom5oxdwqq4rldv0ffph4` (`user_event_feedback_response_id`),
  CONSTRAINT `FKdlh2lom5oxdwqq4rldv0ffph4` FOREIGN KEY (`user_event_feedback_response_id`) REFERENCES `user_event_feedback_response` (`id`),
  CONSTRAINT `FKpdaj25avh1ysblu66plfwqeb3` FOREIGN KEY (`feedback_question_list_id`) REFERENCES `feedback_question` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_event_feedback_response_feedback_question_list`
--

LOCK TABLES `user_event_feedback_response_feedback_question_list` WRITE;
/*!40000 ALTER TABLE `user_event_feedback_response_feedback_question_list` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_event_feedback_response_feedback_question_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_event_registration_detail`
--

DROP TABLE IF EXISTS `user_event_registration_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_event_registration_detail` (
  `id` bigint(20) NOT NULL,
  `event_id` bigint(20) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `user_status_type_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKmj7n1lvfgy4rmsljk3i9k6377` (`event_id`),
  KEY `FKmufxc1dux6ci8ium7ewx4sa7f` (`user_id`),
  KEY `FKg8imu9g7om3julyu4gl45c7r8` (`user_status_type_id`),
  CONSTRAINT `FKg8imu9g7om3julyu4gl45c7r8` FOREIGN KEY (`user_status_type_id`) REFERENCES `user_status_type` (`id`),
  CONSTRAINT `FKmj7n1lvfgy4rmsljk3i9k6377` FOREIGN KEY (`event_id`) REFERENCES `event` (`id`),
  CONSTRAINT `FKmufxc1dux6ci8ium7ewx4sa7f` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_event_registration_detail`
--

LOCK TABLES `user_event_registration_detail` WRITE;
/*!40000 ALTER TABLE `user_event_registration_detail` DISABLE KEYS */;
INSERT INTO `user_event_registration_detail` VALUES (73,2,17,2),(74,2,18,3),(75,2,19,1),(76,2,20,1),(77,2,21,1),(78,2,22,1),(79,2,23,1),(80,2,24,1),(81,2,25,1),(82,2,26,1),(83,2,27,1),(84,2,28,1),(85,2,29,1),(86,2,30,1),(87,2,31,1),(88,2,32,1),(89,2,33,1),(90,2,34,1),(91,2,35,1),(92,2,36,1),(93,2,37,1),(94,4,38,1),(95,4,39,1),(96,4,40,1),(97,4,41,1),(98,4,42,1),(99,4,43,1),(100,4,44,1),(101,4,45,1),(102,4,46,1),(103,4,47,1),(104,4,48,1),(105,4,49,1),(106,4,50,1),(107,4,51,1),(108,6,52,1),(109,6,53,1),(110,6,54,1),(111,6,55,1),(112,8,56,1),(113,8,57,1),(114,10,58,1),(115,10,59,1),(116,12,60,1),(117,12,61,1),(118,14,62,1),(119,14,63,1),(120,14,64,1),(121,14,65,1),(122,14,66,1),(123,16,67,1),(124,16,68,1),(125,16,69,1),(126,16,70,1),(127,16,71,1),(128,16,72,1);
/*!40000 ALTER TABLE `user_event_registration_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_status_type`
--

DROP TABLE IF EXISTS `user_status_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_status_type` (
  `id` bigint(20) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_status_type`
--

LOCK TABLES `user_status_type` WRITE;
/*!40000 ALTER TABLE `user_status_type` DISABLE KEYS */;
INSERT INTO `user_status_type` VALUES (0,'Test123','Test123'),(1,'Participated','Participated'),(2,'Not Participated','Not Participated'),(3,'Un Registered','Un Registered');
/*!40000 ALTER TABLE `user_status_type` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-03 17:02:34
