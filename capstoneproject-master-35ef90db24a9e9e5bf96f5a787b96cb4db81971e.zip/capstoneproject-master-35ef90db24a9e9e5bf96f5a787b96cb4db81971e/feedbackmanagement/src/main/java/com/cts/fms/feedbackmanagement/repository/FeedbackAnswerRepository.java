package com.cts.fms.feedbackmanagement.repository;

import com.cts.fms.feedbackmanagement.domain.FeedbackAnswer;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FeedbackAnswerRepository extends JpaRepository<FeedbackAnswer,Long> {
}
