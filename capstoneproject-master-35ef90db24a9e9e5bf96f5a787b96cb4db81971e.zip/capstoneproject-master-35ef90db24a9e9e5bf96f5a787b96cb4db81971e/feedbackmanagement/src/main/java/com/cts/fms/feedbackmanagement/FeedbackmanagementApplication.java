package com.cts.fms.feedbackmanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FeedbackmanagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(FeedbackmanagementApplication.class, args);
	}

}
