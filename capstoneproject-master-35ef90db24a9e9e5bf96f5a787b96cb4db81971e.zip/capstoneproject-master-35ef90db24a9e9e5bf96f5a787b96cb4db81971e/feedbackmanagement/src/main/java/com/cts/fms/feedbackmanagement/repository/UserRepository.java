package com.cts.fms.feedbackmanagement.repository;

import com.cts.fms.feedbackmanagement.domain.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User,Long> {

    User findByUsername(String username);
}
