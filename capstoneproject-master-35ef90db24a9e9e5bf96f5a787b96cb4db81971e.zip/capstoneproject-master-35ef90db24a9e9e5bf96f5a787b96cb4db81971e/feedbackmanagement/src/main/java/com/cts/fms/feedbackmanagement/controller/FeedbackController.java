package com.cts.fms.feedbackmanagement.controller;

import com.cts.fms.feedbackmanagement.domain.*;
import com.cts.fms.feedbackmanagement.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/feedback/api/v1")
public class FeedbackController {

    @Autowired
    private FeedbackQuestionRepository feedbackQuestionRepository;

    @Autowired
    private FeedbackAnswerRepository feedbackAnswerRepository;

    @Autowired
    private UserStatusTypeRepository userStatusTypeRepository;

    @Autowired
    private UserEventRegistrationDetailRepository userEventRegistrationDetailRepository;

    @Autowired
    private UserRepository userRepository;

    @GetMapping("/listAll")
    public List<FeedbackQuestion> listAll() {
        return feedbackQuestionRepository.findAll();
    }

    @GetMapping("/findById/{id}")
    public Optional<FeedbackQuestion> findById(@PathVariable String id) {
        return feedbackQuestionRepository.findById(Long.parseLong(id));
    }

    @PostMapping("/findByFeedbackName")
    public FeedbackQuestion findByFeedbackName(@RequestBody FeedbackQuestion feedbackQuestion){
        String name = feedbackQuestion.getName();
        return feedbackQuestionRepository.findByName(name);
    }

    @PostMapping("/findByFeedbackType")
    public List<FeedbackQuestion> findByFeedbackType(@RequestBody String feedbackType){
        return feedbackQuestionRepository.findByFeedbackType(feedbackType);
    }

    @PostMapping("/findByUserStatusType")
    public List<FeedbackQuestion> findByUserStatusType(@RequestBody UserStatusType userStatusType){
        UserStatusType userStatusTypeIns = userStatusTypeRepository.findByName(userStatusType.getName());
        return feedbackQuestionRepository.findByUserStatusType(userStatusTypeIns);
    }

    @PostMapping("/deleteFeedbackAnswer")
    public Boolean deleteFeedbackAnswer(@RequestBody Map<String,String> params, HttpServletResponse response){
        System.out.println("params"+params);
        Optional<FeedbackQuestion> feedbackQuestionIns = feedbackQuestionRepository.findById(Long.parseLong(params.get("questionId")));
        FeedbackQuestion feedbackQuestion = feedbackQuestionIns.get();
        System.out.println("feedbackQuestionIns"+feedbackQuestion);
        System.out.println("feedbackAnswerSize:"+feedbackQuestion.getFeedbackAnswerList().size());
        Optional<FeedbackAnswer> feedbackAnswerIns = feedbackQuestion
                                                        .getFeedbackAnswerList()
                                                        .stream()
                                                        .filter(feedbackAnswer -> feedbackAnswer.getId() == Long.parseLong(params.get("answerId")))
                                                        .findAny();
        feedbackQuestion.getFeedbackAnswerList().remove(feedbackAnswerIns.get());
        feedbackQuestionRepository.save(feedbackQuestion);
        response.setStatus(HttpServletResponse.SC_CREATED);
        return Boolean.TRUE;
    }

    @PostMapping("/addFeedbackAnswer")
    public Boolean addFeedbackAnswer(@RequestBody Map<String,String> params, HttpServletResponse response){

        System.out.println("params"+params);
        System.out.println("answerContent"+params.get("answerContent"));
        System.out.println("questionId"+params.get("questionId"));

        String answerContent = params.get("answerContent");

        FeedbackAnswer feedbackAnswer = new FeedbackAnswer(answerContent,answerContent);
        feedbackAnswerRepository.save(feedbackAnswer);

        Optional<FeedbackQuestion> feedbackQuestionIns = feedbackQuestionRepository.findById(Long.parseLong(params.get("questionId")));
        FeedbackQuestion feedbackQuestion = feedbackQuestionIns.get();
        List<FeedbackAnswer> feedbackAnswerList = feedbackQuestion.getFeedbackAnswerList();
        feedbackAnswerList.add(feedbackAnswer);
        feedbackQuestion.setFeedbackAnswerList(feedbackAnswerList);

        feedbackQuestionRepository.save(feedbackQuestion);
        response.setStatus(HttpServletResponse.SC_CREATED);

        return Boolean.TRUE;
    }

    @PostMapping("/attempt")
    public List<FeedbackQuestion> attempt(@RequestBody Map<String,String> params) {
        User user = userRepository.findByUsername(params.get("username"));
        System.out.println("user"+user);
        UserEventRegistrationDetail userEventRegistrationDetail = userEventRegistrationDetailRepository.findByUser(user);
        System.out.println("userEventRegistrationDetail"+userEventRegistrationDetail);
        UserStatusType userStatusType = userStatusTypeRepository.findByName(userEventRegistrationDetail.getUserStatusType().getName());
        List<FeedbackQuestion> feedbackQuestionList = feedbackQuestionRepository.findByUserStatusType(userStatusType);
        return feedbackQuestionList;
    }

}
