package com.cts.fms.feedbackmanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FeedbackmanagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
