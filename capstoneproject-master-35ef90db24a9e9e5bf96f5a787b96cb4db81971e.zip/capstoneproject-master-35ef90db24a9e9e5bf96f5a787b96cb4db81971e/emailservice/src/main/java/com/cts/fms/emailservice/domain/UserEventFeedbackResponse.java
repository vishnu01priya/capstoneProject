package com.cts.fms.emailservice.domain;

import javax.persistence.*;
import java.util.List;

@Entity
public class UserEventFeedbackResponse {

    @Id
    @GeneratedValue
    private Long id;

    @OneToOne(targetEntity=User.class)
    private User participant;

    private Double overallRating;

    @OneToOne(targetEntity=Event.class)
    private Event event;

    @OneToMany(targetEntity = FeedbackQuestion.class)
    private List<FeedbackQuestion> feedbackQuestionList;

    public UserEventFeedbackResponse(){}

    public UserEventFeedbackResponse(User participant, Double overallRating, Event event) {
        this.participant = participant;
        this.overallRating = overallRating;
        this.event = event;
    }

    public User getParticipant() {
        return participant;
    }

    public void setParticipant(User participant) {
        this.participant = participant;
    }

    public Double getOverallRating() {
        return overallRating;
    }

    public void setOverallRating(Double overallRating) {
        this.overallRating = overallRating;
    }

    public Event getEvent() {
        return event;
    }

    public void setEvent(Event event) {
        this.event = event;
    }
}
