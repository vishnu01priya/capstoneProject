package com.cts.fms.emailservice.repository;

import com.cts.fms.emailservice.domain.Event;
import com.cts.fms.emailservice.domain.UserEventRegistrationDetail;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface UserEventRegistrationDetailRepository extends JpaRepository<UserEventRegistrationDetail,Long> {

    List<UserEventRegistrationDetail> findByEvent(Event event);

}
