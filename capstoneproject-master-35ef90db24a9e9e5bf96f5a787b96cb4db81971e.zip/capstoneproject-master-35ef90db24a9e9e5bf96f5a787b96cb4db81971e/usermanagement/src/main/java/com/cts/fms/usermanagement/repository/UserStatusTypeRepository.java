package com.cts.fms.usermanagement.repository;

import com.cts.fms.usermanagement.domain.UserStatusType;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;

public interface UserStatusTypeRepository extends ReactiveCrudRepository<UserStatusType,Long> {
}
