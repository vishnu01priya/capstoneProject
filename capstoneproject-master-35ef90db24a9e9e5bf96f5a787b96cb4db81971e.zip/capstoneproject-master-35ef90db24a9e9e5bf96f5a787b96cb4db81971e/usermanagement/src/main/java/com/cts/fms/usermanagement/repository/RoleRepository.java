package com.cts.fms.usermanagement.repository;

import com.cts.fms.usermanagement.domain.Role;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import reactor.core.publisher.Mono;

public interface RoleRepository extends ReactiveCrudRepository<Role,Long> {

    public Mono<Role> findByName(String name);

}
