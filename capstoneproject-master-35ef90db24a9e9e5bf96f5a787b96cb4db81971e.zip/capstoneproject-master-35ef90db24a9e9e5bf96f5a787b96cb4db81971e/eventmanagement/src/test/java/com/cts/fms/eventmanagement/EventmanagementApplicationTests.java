package com.cts.fms.eventmanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EventmanagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
