package com.cts.fms.eventmanagement.repository;

import com.cts.fms.eventmanagement.domain.UserStatusType;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserStatusTypeRepository extends JpaRepository<UserStatusType,Long> {

}
