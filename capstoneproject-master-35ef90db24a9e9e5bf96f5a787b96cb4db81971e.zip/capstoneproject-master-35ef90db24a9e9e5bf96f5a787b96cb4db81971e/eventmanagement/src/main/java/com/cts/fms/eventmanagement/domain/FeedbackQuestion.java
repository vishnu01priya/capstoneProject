package com.cts.fms.eventmanagement.domain;

import javax.persistence.*;
import java.util.List;

@Entity
public class FeedbackQuestion {

    @Id
    @GeneratedValue
    private Long id;
    private String name;
    private String description;

    @OneToOne(targetEntity = UserStatusType.class)
    private UserStatusType userStatusType;

    @OneToOne(targetEntity = FeedbackType.class)
    private FeedbackType feedbackType;

    @OneToMany(targetEntity = FeedbackAnswer.class)
    private List<FeedbackAnswer> feedbackAnswerList;

    public FeedbackQuestion(Long id, String name, String description) {
        this.id = id;
        this.name = name;
        this.description = description;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
