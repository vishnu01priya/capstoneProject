package com.cts.fms.feedbackmanagementclient.controller;

import com.cts.fms.feedbackmanagementclient.domain.Dashboard;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/email/api/v1")
public class EmailController {

    @Autowired
    private WebClient.Builder webClientBuilder;

    @GetMapping("/sendEmail")
    @PreAuthorize("hasRole('admin') || hasRole('pmo') || hasRole('poc')")
    public Mono<Boolean> dashboard() {
        return webClientBuilder.build().get()
                .uri("http://emailservice/email/api/v1/sendEmail")
                .accept(MediaType.APPLICATION_JSON)
                .retrieve()
                .bodyToMono(Boolean.class).log();
    }

    @GetMapping("/sendEventEmail/{eventId}")
    @PreAuthorize("hasRole('admin') || hasRole('pmo') || hasRole('poc')")
    public Mono<Boolean> sendEventEmail(@PathVariable String eventId) {
        return webClientBuilder.build().get()
                .uri("http://emailservice/email/api/v1/sendEventEmail/"+eventId)
                .accept(MediaType.APPLICATION_JSON)
                .retrieve()
                .bodyToMono(Boolean.class).log();
    }

}
