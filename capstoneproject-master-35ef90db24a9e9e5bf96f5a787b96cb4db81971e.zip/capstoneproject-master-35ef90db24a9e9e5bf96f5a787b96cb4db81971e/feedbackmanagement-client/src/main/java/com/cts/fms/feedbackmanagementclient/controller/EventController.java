package com.cts.fms.feedbackmanagementclient.controller;

import com.cts.fms.feedbackmanagementclient.domain.Dashboard;
import com.cts.fms.feedbackmanagementclient.domain.Event;
import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.InputStream;
import java.util.Map;

import static org.bouncycastle.crypto.tls.CipherType.stream;
import static org.springframework.http.MediaType.APPLICATION_OCTET_STREAM_VALUE;

@RestController
@RequestMapping("/event/api/v1/")
public class EventController {

    @Autowired
    private WebClient.Builder webClientBuilder;

    @GetMapping("/listAll")
    @PreAuthorize("hasRole('admin') || hasRole('pmo')")
    public Flux<Event> listAll() {
        return webClientBuilder.build().get()
                .uri("http://eventmanagement-service/event/api/v1/listAll")
                .accept(MediaType.APPLICATION_JSON)
                .retrieve()
                .bodyToFlux(Event.class).log();
    }

    @GetMapping("/findByEventId/{eventId}")
    @PreAuthorize("hasRole('admin') || hasRole('pmo') || hasRole('poc')")
    public Mono<Event> findByEventId(@PathVariable  String eventId) {
        return webClientBuilder.build().get()
                .uri("http://eventmanagement-service/event/api/v1/findByEventId/"+eventId)
                .accept(MediaType.APPLICATION_JSON)
                .retrieve()
                .bodyToMono(Event.class).log();
    }

    @GetMapping("/dashboard")
    @PreAuthorize("hasRole('admin') || hasRole('pmo')")
    public Mono<Dashboard> dashboard() {
        return webClientBuilder.build().get()
                .uri("http://eventmanagement-service/event/api/v1/dashboard")
                .accept(MediaType.APPLICATION_JSON)
                .retrieve()
                .bodyToMono(Dashboard.class).log();
    }

    @PostMapping("/pocDashboard")
    @PreAuthorize("hasRole('poc')")
    public Mono<Dashboard> pocDashboard(@RequestBody Map<String,String> params) {
        Mono<Map> paramsMono = Mono.just(params);
        return webClientBuilder.build().post()
                .uri("http://eventmanagement-service/event/api/v1/pocDashboard")
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .body(paramsMono,Map.class)
                .retrieve()
                .bodyToMono(Dashboard.class).log();
    }

    @PostMapping(path = "api/v1/attachment",produces = APPLICATION_OCTET_STREAM_VALUE)
    @PreAuthorize("hasRole('admin') || hasRole('pmo') || hasRole('poc')")
    public void getAttachment(HttpServletResponse response,@RequestBody Map<String,String> params) throws IOException {
        Mono<Map> paramsMono = Mono.just(params);
        InputStream mono  = webClientBuilder.build().post()
                .uri("http://eventmanagement-service/event/api/v1/download/report.xlsx")
                .accept(MediaType.APPLICATION_OCTET_STREAM)
                .body(paramsMono,Map.class)
                .exchange()
                .flatMap(res -> res.bodyToMono(InputStreamResource.class))
                .map(inputStreamResource -> {
                    try {
                        return inputStreamResource.getInputStream();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    return null;
                }).block();
        response.setContentType("application/octet-stream");
        response.setHeader("Content-Disposition", "attachment; filename=report.xlsx");
        IOUtils.copy(mono, response.getOutputStream());
    }

}
