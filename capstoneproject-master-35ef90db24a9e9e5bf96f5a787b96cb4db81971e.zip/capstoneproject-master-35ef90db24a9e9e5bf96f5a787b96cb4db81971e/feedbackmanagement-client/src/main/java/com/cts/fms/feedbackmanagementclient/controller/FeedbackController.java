package com.cts.fms.feedbackmanagementclient.controller;

import com.cts.fms.feedbackmanagementclient.domain.FeedbackQuestion;
import com.cts.fms.feedbackmanagementclient.domain.UserStatusType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.Map;

@RestController
@RequestMapping("/feedback/api/v1")
public class FeedbackController {

    @Autowired
    private WebClient.Builder webClientBuilder;

    @GetMapping("/listAll")
    @PreAuthorize("hasRole('admin')")
    public Flux<FeedbackQuestion> listAll() {
        return webClientBuilder.build().get()
                .uri("http://feedbackmanagement-service/feedback/api/v1/listAll")
                .accept(MediaType.APPLICATION_JSON)
                .retrieve()
                .bodyToFlux(FeedbackQuestion.class).log();
    }

    @GetMapping("/findById/{id}")
    @PreAuthorize("hasRole('admin')")
    public Mono<FeedbackQuestion> findById(@PathVariable String id){
        return webClientBuilder.build().get()
                .uri("http://feedbackmanagement-service/feedback/api/v1/findById/"+id)
                .accept(MediaType.APPLICATION_JSON)
                .retrieve()
                .bodyToMono(FeedbackQuestion.class).log();
    }

    @PostMapping("/findByFeedbackName")
    @PreAuthorize("hasRole('admin')")
    public Mono<FeedbackQuestion> findByFeedbackName(@RequestBody FeedbackQuestion feedbackQuestion) {
        Mono<FeedbackQuestion> feedbackQuestionMono = Mono.just(feedbackQuestion);
        return webClientBuilder.build().post()
                .uri("http://feedbackmanagement-service/feedback/api/v1/findByFeedbackName")
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .body(feedbackQuestionMono,FeedbackQuestion.class)
                .retrieve()
                .bodyToMono(FeedbackQuestion.class).log();

    }

    @PostMapping("/findByFeedbackType")
    @PreAuthorize("hasRole('admin')")
    public Flux<FeedbackQuestion> findByFeedbackType(@RequestBody String feedbackType) {
        Mono<String> feedbackTypeMono = Mono.just(feedbackType);
        return webClientBuilder.build().post()
                .uri("http://feedbackmanagement-service/feedback/api/v1/findByFeedbackType")
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .body(feedbackTypeMono,String.class)
                .retrieve()
                .bodyToFlux(FeedbackQuestion.class).log();
    }

    @PostMapping("/findByUserStatusType")
    @PreAuthorize("hasRole('admin')")
    public Flux<FeedbackQuestion> findByUserStatusType(@RequestBody UserStatusType userStatusType) {
        Mono<UserStatusType> userStatusTypeMono = Mono.just(userStatusType);
        return webClientBuilder.build().post()
                .uri("http://feedbackmanagement-service/feedback/api/v1/findByUserStatusType")
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .body(userStatusTypeMono,UserStatusType.class)
                .retrieve()
                .bodyToFlux(FeedbackQuestion.class).log();
    }
    
    @PostMapping("/deleteFeedbackAnswer")
    @PreAuthorize("hasRole('admin')")
    public Mono<Boolean> deleteFeedbackAnswer(@RequestBody Map<String,String> params){
    	System.out.println("params"+params);
        System.out.println("answerId"+params.get("answerId"));
        System.out.println("questionId"+params.get("questionId"));
        Mono<Map> paramsMono = Mono.just(params);
        return webClientBuilder.build().post()
                .uri("http://feedbackmanagement-service/feedback/api/v1/deleteFeedbackAnswer")
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .body(paramsMono,Map.class)
                .retrieve()
                .bodyToMono(Boolean.class).log();
    }

    @PostMapping("/addFeedbackAnswer")
    @PreAuthorize("hasRole('admin')")
    public Mono<Boolean> addFeedbackAnswer(@RequestBody Map<String,String> params){
        System.out.println("params"+params);
        System.out.println("answerContent"+params.get("answerContent"));
        System.out.println("questionId"+params.get("questionId"));
        Mono<Map> paramsMono = Mono.just(params);
        return webClientBuilder.build().post()
                .uri("http://feedbackmanagement-service/feedback/api/v1/addFeedbackAnswer")
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .body(paramsMono,Map.class)
                .retrieve()
                .bodyToMono(Boolean.class).log();
    }

    @PostMapping("/attempt")
    @PreAuthorize("hasRole('associate')")
    public Flux<FeedbackQuestion> attempt(@RequestBody Map<String,String> params) {
        Mono<Map> paramsMono = Mono.just(params);
        return webClientBuilder.build().post()
                .uri("http://feedbackmanagement-service/feedback/api/v1/attempt")
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .body(paramsMono,Map.class)
                .retrieve()
                .bodyToFlux(FeedbackQuestion.class).log();
    }

}
