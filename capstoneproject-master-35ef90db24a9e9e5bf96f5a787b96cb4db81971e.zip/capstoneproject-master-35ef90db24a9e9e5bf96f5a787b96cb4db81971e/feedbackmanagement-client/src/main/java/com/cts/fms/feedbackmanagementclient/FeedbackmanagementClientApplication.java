package com.cts.fms.feedbackmanagementclient;

import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.web.reactive.function.client.WebClient;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

import java.security.Security;

@SpringBootApplication
@EnableSwagger2
public class FeedbackmanagementClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(FeedbackmanagementClientApplication.class, args);
	}

	@Bean
	@LoadBalanced
	public WebClient.Builder getWebClintBuilder() {
		return WebClient.builder();
	}
}
