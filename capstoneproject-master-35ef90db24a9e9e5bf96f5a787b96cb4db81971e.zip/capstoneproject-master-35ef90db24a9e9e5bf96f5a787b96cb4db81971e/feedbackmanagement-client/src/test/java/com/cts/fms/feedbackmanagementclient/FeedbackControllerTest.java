package com.cts.fms.feedbackmanagementclient;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.reactive.server.WebTestClient;
import reactor.core.publisher.Mono;

import java.util.HashMap;
import java.util.Map;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class FeedbackControllerTest {

    @Autowired
    private WebTestClient webClient;

    @Test
    public void testAddFeedbackAnswer() {
        Map<String,String> params = new HashMap<String,String>();
        params.put("questionId","1");
        params.put("answerContent","Unit Testing3");
        Mono<Map> paramsMono = Mono.just(params);
        this.webClient.post()
                .uri("http://localhost:8084/feedback/api/v1/addFeedbackAnswer")
                .contentType(MediaType.APPLICATION_JSON)
                .body(paramsMono,Map.class)
                .exchange()
                .expectStatus().isCreated();

    }

    @Test
    public void testDeleteFeedbackAnswer() {
        Map<String,String> params = new HashMap<String,String>();
        params.put("questionId","1");
        params.put("answerId","144");
        Mono<Map> paramsMono = Mono.just(params);
        this.webClient.post()
                .uri("http://localhost:8084/feedback/api/v1/deleteFeedbackAnswer")
                .contentType(MediaType.APPLICATION_JSON)
                .body(paramsMono,Map.class)
                .exchange()
                .expectStatus().isCreated();
    }

}
