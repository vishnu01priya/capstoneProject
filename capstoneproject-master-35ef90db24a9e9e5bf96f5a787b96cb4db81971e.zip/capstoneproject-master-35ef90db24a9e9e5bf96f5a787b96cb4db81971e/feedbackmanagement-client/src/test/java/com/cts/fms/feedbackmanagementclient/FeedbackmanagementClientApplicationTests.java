package com.cts.fms.feedbackmanagementclient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FeedbackmanagementClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
