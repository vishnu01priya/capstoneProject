package com.cts.fms.feedbackmanagementclient;

import com.cts.fms.feedbackmanagementclient.domain.Dashboard;
import com.cts.fms.feedbackmanagementclient.domain.Event;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.reactive.server.WebTestClient;
import reactor.core.publisher.Mono;

import java.util.HashMap;
import java.util.Map;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class EventControllerTest {

    @Autowired
    private WebTestClient webClient;

    @Test
    public void testEventListApi() {
        this.webClient.get().uri("http://localhost:8082/event/api/v1/listAll")
                .exchange()
                .expectStatus().isOk()
                .expectHeader().contentType(MediaType.APPLICATION_JSON)
                .expectBodyList(Event.class)
                .hasSize(8);
    }

    @Test
    public void  testFindByEventId() {
        String eventId = "EVNT00047261";
        this.webClient.get().uri("http://localhost:8082/event/api/v1/findByEventId/"+eventId)
                .exchange()
                .expectStatus().isOk()
                .expectHeader().contentType(MediaType.APPLICATION_JSON)
                .expectBody(Event.class);
    }

    @Test
    public void  testPocDashboard() {
        Map<String,String> params = new HashMap<String,String>();
        params.put("username","testpoc");
        Mono<Map> paramsMono = Mono.just(params);
        this.webClient.post().uri("http://localhost:8082/event/api/v1/pocDashboard")
                .contentType(MediaType.APPLICATION_JSON)
                .body(paramsMono,Map.class)
                .exchange()
                .expectStatus().isOk()
                .expectBody(Dashboard.class);

    }

}
