package com.cts.fms.datamigration.repository;

import com.cts.fms.datamigration.domain.FeedbackAnswer;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FeedbackAnswerRepository extends JpaRepository<FeedbackAnswer,Long> {
}
