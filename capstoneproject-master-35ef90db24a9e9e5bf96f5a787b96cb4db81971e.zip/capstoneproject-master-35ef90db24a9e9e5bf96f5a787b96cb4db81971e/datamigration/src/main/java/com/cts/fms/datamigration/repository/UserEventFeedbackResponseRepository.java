package com.cts.fms.datamigration.repository;

import com.cts.fms.datamigration.domain.UserEventFeedbackResponse;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserEventFeedbackResponseRepository extends JpaRepository<UserEventFeedbackResponse,Long> {
}
