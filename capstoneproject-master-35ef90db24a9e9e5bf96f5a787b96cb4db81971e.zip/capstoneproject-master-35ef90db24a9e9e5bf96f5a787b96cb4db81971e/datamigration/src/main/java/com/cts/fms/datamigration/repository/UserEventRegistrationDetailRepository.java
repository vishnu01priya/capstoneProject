package com.cts.fms.datamigration.repository;

import com.cts.fms.datamigration.domain.Event;
import com.cts.fms.datamigration.domain.User;
import com.cts.fms.datamigration.domain.UserEventRegistrationDetail;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserEventRegistrationDetailRepository extends JpaRepository<UserEventRegistrationDetail,Long> {

    UserEventRegistrationDetail findByUserAndEvent(User userIns, Event eventIns);
}
