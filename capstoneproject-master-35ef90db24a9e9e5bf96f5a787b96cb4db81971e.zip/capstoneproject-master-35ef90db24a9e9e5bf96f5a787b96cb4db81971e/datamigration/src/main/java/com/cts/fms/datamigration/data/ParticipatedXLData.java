package com.cts.fms.datamigration.data;

public class ParticipatedXLData {

    private String eventId;
    private String baseLocation;
    private String beneficiaryName;
    private String councilName;
    private String eventName;
    private String eventDescription;
    private String eventDate;
    private String employeeId;
    private String employeeName;
    private Integer volunteerHours;
    private Integer travelHours;
    private Integer livesImpacted;
    private String businessUnit;
    private String status;
    private String category;

    public ParticipatedXLData(String eventId, String baseLocation, String beneficiaryName, String councilName, String eventName, String eventDescription, String eventDate, String employeeId, String employeeName, Integer volunteerHours, Integer travelHours, Integer livesImpacted, String businessUnit, String status, String category) {
        this.eventId = eventId;
        this.baseLocation = baseLocation;
        this.beneficiaryName = beneficiaryName;
        this.councilName = councilName;
        this.eventName = eventName;
        this.eventDescription = eventDescription;
        this.eventDate = eventDate;
        this.employeeId = employeeId;
        this.employeeName = employeeName;
        this.volunteerHours = volunteerHours;
        this.travelHours = travelHours;
        this.livesImpacted = livesImpacted;
        this.businessUnit = businessUnit;
        this.status = status;
        this.category = category;
    }

    public ParticipatedXLData() {

    }

    public String getEventId() {
        return eventId;
    }

    public void setEventId(String eventId) {
        this.eventId = eventId;
    }

    public String getBaseLocation() {
        return baseLocation;
    }

    public void setBaseLocation(String baseLocation) {
        this.baseLocation = baseLocation;
    }

    public String getBeneficiaryName() {
        return beneficiaryName;
    }

    public void setBeneficiaryName(String beneficiaryName) {
        this.beneficiaryName = beneficiaryName;
    }

    public String getCouncilName() {
        return councilName;
    }

    public void setCouncilName(String councilName) {
        this.councilName = councilName;
    }

    public String getEventName() {
        return eventName;
    }

    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

    public String getEventDescription() {
        return eventDescription;
    }

    public void setEventDescription(String eventDescription) {
        this.eventDescription = eventDescription;
    }

    public String getEventDate() {
        return eventDate;
    }

    public void setEventDate(String eventDate) {
        this.eventDate = eventDate;
    }

    public String getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(String employeeId) {
        this.employeeId = employeeId;
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }

    public Integer getVolunteerHours() {
        return volunteerHours;
    }

    public void setVolunteerHours(Integer volunteerHours) {
        this.volunteerHours = volunteerHours;
    }

    public Integer getTravelHours() {
        return travelHours;
    }

    public void setTravelHours(Integer travelHours) {
        this.travelHours = travelHours;
    }

    public Integer getLivesImpacted() {
        return livesImpacted;
    }

    public void setLivesImpacted(Integer livesImpacted) {
        this.livesImpacted = livesImpacted;
    }

    public String getBusinessUnit() {
        return businessUnit;
    }

    public void setBusinessUnit(String businessUnit) {
        this.businessUnit = businessUnit;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }
}
