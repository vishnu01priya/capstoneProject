package com.cts.fms.datamigration.repository;

import com.cts.fms.datamigration.domain.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User,Long> {

    User findByUsername(String username);
}
