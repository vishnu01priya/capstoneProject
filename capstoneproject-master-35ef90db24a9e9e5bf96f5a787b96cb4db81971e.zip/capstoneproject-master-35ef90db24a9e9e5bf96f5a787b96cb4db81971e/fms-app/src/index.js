import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import * as serviceWorker from './serviceWorker';
import axios from 'axios';
import 'bootstrap/dist/js/bootstrap.js';
import $ from 'jquery';
import Popper from 'popper.js';
import * as Keycloak from 'keycloak-js'
let initOptions = {
  url: 'http://127.0.0.1:8080/auth', realm: 'fms', clientId: 'fms-react', onLoad: 'login-required'
}

let keycloak = Keycloak(initOptions);

keycloak.init({ onLoad: initOptions.onLoad }).success((auth) => {
  
  console.log("keycloak",keycloak);
  if (!auth) {
      window.location.reload();
  } else {
      console.info("Authenticated");
  }

  localStorage.setItem("react-token", keycloak.token);
  localStorage.setItem("react-refresh-token", keycloak.refreshToken);
  localStorage.setItem("username",keycloak.idTokenParsed.preferred_username);
  
  if(keycloak.realmAccess.roles.includes("admin")) {
    localStorage.setItem("role","admin");
  } else if(keycloak.realmAccess.roles.includes("pmo")) {
    localStorage.setItem("role","pmo");
  } else if(keycloak.realmAccess.roles.includes("poc")){
    localStorage.setItem("role","poc");
  } else {
    localStorage.setItem("role","associate");
  }

  axios.defaults.baseURL = "http://localhost:8090";

  axios.interceptors.request.use(request => {

    request.headers.Authorization = `Bearer ${localStorage.getItem("react-token")}`;

    request.headers['Access-Control-Allow-Origin'] = '*';
    request.headers['Access-Control-Allow-Credentials'] = 'true';
    
    console.log(request);
    return request;
  }, error => {
    console.log(error);
    return Promise.reject(error);
  });

  axios.interceptors.response.use(response => {
    console.log("status code",response.status);
    if(response.status == "403") {
      
    }
    return response;
  }, error => {
    console.log(error);
    return Promise.reject(error);
  });


  ReactDOM.render(
    <React.StrictMode>
      <App />
    </React.StrictMode>,
    document.getElementById('root')
  );

  setTimeout(() => {
      keycloak.updateToken(70).success((refreshed) => {
          if (refreshed) {
              console.debug('Token refreshed' + refreshed);
          } else {
              console.warn('Token not refreshed, valid for '
                  + Math.round(keycloak.tokenParsed.exp + keycloak.timeSkew - new Date().getTime() / 1000) + ' seconds');
          }
      }).error(() => {
          console.error('Failed to refresh token');
      });
  }, 60000)

}).error(() => {
    console.error("Authenticated Failed");
});

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();
