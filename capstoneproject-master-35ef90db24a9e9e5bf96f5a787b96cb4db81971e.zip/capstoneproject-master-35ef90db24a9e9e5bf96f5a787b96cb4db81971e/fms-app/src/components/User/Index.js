import React from 'react';

const UserIndex = React.memo( props => {

    return(
        <React.Fragment>

        </React.Fragment>
    )

});

export default UserIndex;