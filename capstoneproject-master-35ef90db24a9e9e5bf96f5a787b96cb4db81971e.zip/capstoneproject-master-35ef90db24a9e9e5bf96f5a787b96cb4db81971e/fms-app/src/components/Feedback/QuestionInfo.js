import React, { useEffect, useState } from 'react';
import axios from 'axios';
import Loading from '../global/Loading';
import { Link } from "react-router-dom";
import $ from 'jquery';

const QuestionInfo = React.memo(props => {

    const [questionInfo,setQuestionInfo] = useState({});
    const [dataFetch, setDataFetch] = useState(false);
    const [newAnswer,setNewAnswer] = useState('');

    const fetchData = async () => {
        let questionId = props.location.data.questionId;
        //console.log("questionId"+questionId);
        axios("/feedback/api/v1/findById/"+questionId).then(
            res => {
                setQuestionInfo(res.data);
                setDataFetch(true);
                console.log(res.data);
            }
        );
    }

    useEffect(() => {
        fetchData();
    },[]);

    const deleteAnswer = (answerId,questionId) => {
        setDataFetch(true);
        axios({
            crossDomain: true,
            method: 'POST',
            url: '/feedback/api/v1/deleteFeedbackAnswer',
            data: {
                answerId: answerId,
                questionId: questionId
            }
          }).then((response) => {
            console.log(response);
            if(response.data === true) {
                fetchData();
            }
            setDataFetch(false);
          }, (error) => {
            console.log(error);
          });

    }

    const addFeedbackAnswer = (answerContent,questionId) => {
        setDataFetch(true);
        axios({
            crossDomain: true,
            method: 'POST',
            url: '/feedback/api/v1/addFeedbackAnswer',
            data: {
                answerContent: answerContent,
                questionId: questionId
            }
        }).then((response) => {
            console.log("response",response)
            if(response.data === true) {
                setNewAnswer("");
                fetchData();
            }
            //setDataFetch(false);
        }, (error) => {
            console.log(error);
        });
    }

    return(
        <React.Fragment>
            {dataFetch ? (
                <div className="card">
                    <h5 className="card-header text-white bg-primary">Edit : {questionInfo.name}</h5>
                    <div className="card-body">
                        <div className="row mb-4">
                            <div className="col-lg-2 col-md-2 col-sm-2 col-xs-2" role="group">
                                <div className="form-group">
                                    <label><b>Feedback Type : </b></label>
                                    <div>
                                        <div className="form-check">
                                            <input className="form-check-input" type="checkbox" name="inlineRadioOptions" id="inlineRadio1" value="option1" checked={questionInfo.feedbackType == "Multiple Answers" ? "checked" : ""} />
                                            <label className="form-check-label" htmlFor="inlineRadio1">Multiple Answers</label>
                                        </div>
                                        <div className="form-check">
                                            <input className="form-check-input" type="checkbox" name="inlineRadioOptions" id="inlineRadio2" value="option2" checked={questionInfo.feedbackType == "Free Text Answer" ? "checked" : ""} />
                                            <label className="form-check-label" htmlFor="inlineRadio2">Free Text Answer</label>
                                        </div>
                                        <div className="form-check">
                                            <input className="form-check-input" type="checkbox" name="inlineRadioOptions" id="inlineRadio3" value="option3" checked={questionInfo.feedbackType == "Custom Question" ? "checked" : ""} />
                                            <label className="form-check-label" htmlFor="inlineRadio3">Custom Question</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div className="col-lg-10 col-md-10 col-sm-10 col-xs-10">
                                <div>
                                    <div className="form-check form-check-inline">
                                        <input className="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="option1" checked={questionInfo.userStatusType.name == "Participated" ? "checked" : ""}  />
                                        <label className="form-check-label" htmlFor="inlineRadio1">Participated</label>
                                    </div>
                                    <div className="form-check form-check-inline">
                                        <input className="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="option2" checked={questionInfo.userStatusType.name == "Not Participated" ? "checked" : ""} />
                                        <label className="form-check-label" htmlFor="inlineRadio2">Not Participated</label>
                                    </div>
                                    <div className="form-check form-check-inline">
                                        <input className="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio3" value="option3" checked={questionInfo.userStatusType.name == "Un Registered" ? "checked" : ""} />
                                        <label className="form-check-label" htmlFor="inlineRadio3">Unregistered</label>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="row mb-4">
                            <div className="col-lg-2 col-md-2 col-sm-2 col-xs-2" role="group">
                                <label><b>Question : </b></label>
                            </div>
                            <div className="col-lg-10 col-md-10 col-sm-10 col-xs-10">
                            <textarea className="form-control" id="validationTextarea" placeholder="you're thoughts here" required>{questionInfo.description}</textarea>
                                
                            </div>
                        </div>

                            {
                                questionInfo.feedbackAnswerList.map((feedbackAnswerIns,fbi) => (
                                    <div className="row mb-4" key={"feedbackAnswer_"+feedbackAnswerIns.id}>
                                        <div className="col-lg-2 col-md-2 col-sm-2 col-xs-2" role="group">
                                            <label><b>{"Answer - "+fbi} </b></label>
                                        </div>
                                        <div className="col-lg-8 col-md-8 col-sm-8 col-xs-8">
                                            <input type="text" className="form-control" aria-label="Text input with checkbox" value={feedbackAnswerIns.name} />
                                        </div>
                                        <div className="col-lg-2 col-md-2 col-sm-2 col-xs-2" role="group">
                                            <button type="button" className="btn btn-danger" onClick={() => deleteAnswer(feedbackAnswerIns.id,questionInfo.id)}>Delete Answer</button>
                                        </div>
                                    </div>
                                ))
                            }
                            

                        <div className="row mb-4">
                            <div className="col-lg-2 col-md-2 col-sm-2 col-xs-2" role="group">
                                    <button type="button" className="btn btn-secondary" data-toggle="modal" data-target="#exampleModal">Add Answer</button>
                            </div>
                            <div className="col-lg-10 col-md-10 col-sm-10 col-xs-10">
                                
                            </div>
                        </div>
                    </div>
                    <div className="modal fade" id="exampleModal" tabIndex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div className="modal-dialog" role="document">
                            <div className="modal-content">
                            <div className="modal-header">
                                <h5 className="modal-title" id="exampleModalLabel">{questionInfo.description}</h5>
                                <button type="button" className="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div className="modal-body">
                            <form>
                                <div className="form-group">
                                    <label for="exampleInputEmail1"><b>Answer</b></label>
                                    <input type="email" className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" value={newAnswer} onChange={event => setNewAnswer(event.target.value)} />
                                </div>
                            </form>

                            </div>
                            <div className="modal-footer">
                                <button type="button" className="btn btn-secondary" data-dismiss="modal" >Close</button>
                                <button type="button" className="btn btn-primary" data-dismiss="modal" onClick={() => addFeedbackAnswer(newAnswer,questionInfo.id)}>Add</button>
                            </div>
                            </div>
                        </div>
                    </div>
                </div>
            ) : (
                <Loading />
            )}
        </React.Fragment>
    )    
});

export default QuestionInfo;