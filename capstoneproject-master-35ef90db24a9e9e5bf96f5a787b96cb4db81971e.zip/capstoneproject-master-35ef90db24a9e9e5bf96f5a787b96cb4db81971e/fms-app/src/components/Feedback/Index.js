import React, { useEffect, useState } from 'react';
import axios from 'axios';
import Loading from '../global/Loading';
import { Link } from "react-router-dom";

const QuestionList = React.memo(props => {

    const [questionList,setQuestionList] = useState([]);
    const [dataFetch, setDataFetch] = useState(false);

    useEffect(() => {
        const fetchData = async () => {
            axios("/feedback/api/v1/listAll").then(
                res => {
                    setQuestionList(res.data);
                    setDataFetch(true);
                }
            );
            
        }
        fetchData();
    },[]);

    return(
        <React.Fragment>
            {dataFetch ? (
                <div>
                <div className="card">
                    <div className="card-header" style={{ textAlign: "left" }}>
                    Feedback Questions
                    {console.log(questionList)}
                    </div>
                    <div className="card-body">
                    <div className="table-responsive">
                        <table className="table table-sm table-bordered">
                        <thead>
                            <tr>
                            <th scope="col">Questions</th>
                            <th scope="col">Total Answers</th>
                            <th scope="col">Feedback Type</th>
                            </tr>
                        </thead>
                        <tbody>
                        {questionList.map(questionIns => (
                            <tr key={questionIns.id}>
                            <th scope="row">
                              <Link
                                to={{
                                  pathname: "/feedback/questioninfo",
                                  data: {
                                    questionId: questionIns.id
                                  }
                                }}
                              >
                                {questionIns.name}
                              </Link>
                            </th>
                            <td>{questionIns.feedbackAnswerList.length}</td>
                            <td>{questionIns.feedbackType}</td>
                          </tr>
                        ))}
                        </tbody>
                        </table>
                    </div>
                    </div>
                </div>
                </div>
            ) : (
                <Loading />
            )}
        </React.Fragment>
    )

})

export default QuestionList;