import React, { useEffect, useState } from 'react';
import axios from 'axios';
import Loading from '../global/Loading';
import Attempted from './Attempted';
import NotAttempted from './NotAttempted';

const Attempt = React.memo(props => {

    const [feedbackQuestionList,setFeedbackQuestionList] = useState([]);
    const [showLoading,setShowLoading] = useState(true);

    useEffect(() => {

        fetchAttempt();

    },[])

    const fetchAttempt = () => {
        setShowLoading(true);
        axios({
            crossDomain: true,
            method: 'POST',
            url: '/feedback/api/v1/attempt',
            data: {
                username: localStorage.getItem('username')
            }
          }).then((response) => {
            console.log("attempt",response);
            setFeedbackQuestionList(response.data);
            setShowLoading(false);
          }, (error) => {
            console.log(error);
          });
    }


    return(
        <React.Fragment>
            {
                showLoading ? <Loading /> : 
                feedbackQuestionList.map(feedbackQuestionIns => (
                    feedbackQuestionIns.userStatusType.name == 'Participated' ?  <Attempted feedbackQuestion={feedbackQuestionIns} /> : 
                    feedbackQuestionIns.userStatusType.name == 'Not Participated' ?  <NotAttempted feedbackQuestion={feedbackQuestionIns} /> : 
                    feedbackQuestionIns.userStatusType.name == 'Un Registered' ?  <NotAttempted feedbackQuestion={feedbackQuestionIns} /> : <Loading />
                ))
            }
        </React.Fragment>
    )


});

export default Attempt;