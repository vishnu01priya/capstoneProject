import React, { useEffect, useState } from 'react';
import axios from 'axios';
import Loading from '../global/Loading';


const NotAttempted = React.memo(resp =>{

    const [feedbackQuestion,setFeedbackQuestion] = useState({});
    const [showLoading,setShowLoading] = useState(true);
    const [feedbackAnswerStatus,setFeedbackAnswerStatus] = useState([]);
    const [selectedAnswerId,setSelectedAnswerId] = useState({});

    useEffect(() => {
        setFeedbackQuestion(resp.feedbackQuestion);
        resp.feedbackQuestion.feedbackAnswerList.forEach(function() {
            feedbackAnswerStatus.push(false);
        });
        setShowLoading(false);
    },[])

    const updateFeedbackAnswer = (answerIndex,answerId) => {
        var feedbackAnswerStatusList = [...feedbackAnswerStatus];
        feedbackAnswerStatusList.forEach(function(status,index){
            if(answerIndex === index) {
                feedbackAnswerStatusList[index] = true
                setSelectedAnswerId(answerId);
            } else {
                feedbackAnswerStatusList[index] = false
            }
        })
        setFeedbackAnswerStatus(feedbackAnswerStatusList);
    }

    const submitFeedback = () => {
        console.log('questions',feedbackQuestion.id);
        console.log('selectedAnswerId',selectedAnswerId);
    }

    return(
        <React.Fragment>
            { showLoading ? <Loading /> : 
                <div className="row">
                    <div className="card">
                        <div className="card-header text-white bg-primary">
                            <span style={{float:"left"}}>
                                {feedbackQuestion.description}
                            </span>
                        </div>
                        <div className="card-body">
                            <div class="row">
                                {
                                    feedbackQuestion.feedbackAnswerList.map((feedbackAnswerIns,index) => (
                                        <div class="col-sm-4 mb-4" key={"feedbackAnswer_"+feedbackAnswerIns.id} onClick={() => updateFeedbackAnswer(index,feedbackAnswerIns.id)}>
                                            <div class="card text-white bg-info mb-3" style={{cursor:'pointer'}}>
                                                <div class="card-body" style={{maxHeight:90}}>
                                                <span>{feedbackAnswerIns.name}</span>
                                                {feedbackAnswerStatus[index] === true ? <span style={{float:'right'}}><i class="fas fa-check-circle"></i></span> : '' }
                                                </div>
                                            </div>
                                        </div>
                                    ))
                                }
                            </div>
                        </div>
                        <div className="modal-footer" style={{borderTop:0}}>
                            <button type="button" className="btn btn-danger" style={{float:'right'}}>Reset</button>
                            <button type="button" className="btn btn-primary" style={{float:'right'}} onClick={() => submitFeedback()}>Submit</button>
                        </div>
                    </div>
                </div>
            }
        </React.Fragment>
    )

})

export default NotAttempted;
