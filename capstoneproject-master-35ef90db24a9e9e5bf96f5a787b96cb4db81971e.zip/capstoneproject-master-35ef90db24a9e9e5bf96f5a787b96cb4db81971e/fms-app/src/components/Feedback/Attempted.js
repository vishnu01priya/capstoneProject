import React, { useEffect, useState } from 'react';
import axios from 'axios';
import Loading from '../global/Loading';


const Attempted = React.memo(resp => {

    const [feedbackQuestion,setFeedbackQuestion] = useState({});

    useEffect(() => {
        console.log("props",resp.feedbackQuestion);
        setFeedbackQuestion(resp.feedbackQuestion);
    },[])

    return(
        <React.Fragment>
            <div className="row">
                <div className="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div className="card">
                        <div className="card-header text-white bg-primary">
                            <span style={{float:"left"}}>
                                How do you rate the overall event?
                            </span>
                        </div>
                        <div className="card-body">
                            <h5 className="card-title" style={{display:'inline',padding: '3.25em'}}><i className='fas fa-angry' style={{fontSize:48,color:'red',cursor:'pointer'}}></i></h5>
                            <h5 className="card-title" style={{display:'inline',padding: '3.25em'}}><i className='far fa-frown' style={{fontSize:48,color:'orange',cursor:'pointer'}}></i></h5>
                            <h5 className="card-title" style={{display:'inline',padding: '3.25em'}}><i className='far fa-meh' style={{fontSize:48,color:'red',cursor:'pointer'}}></i></h5>
                            <h5 className="card-title" style={{display:'inline',padding: '3.25em'}}><i className='far fa-grin' style={{fontSize:48,color:'#05b705',cursor:'pointer'}}></i></h5>
                            <h5 className="card-title" style={{display:'inline',padding: '3.25em'}}><i className='far fa-grin-hearts' style={{fontSize:48,color:'green',cursor:'pointer'}}></i></h5>
                        </div>
                    </div>
                    <div className="card">
                        <div className="card-header text-white bg-primary">
                            <span style={{float:"left"}}>
                                What did you like about this volunteering activity?
                            </span>
                        </div>
                        <div className="card-body">
                            <textarea className="form-control" id="validationTextarea" placeholder="you're thoughts here" required></textarea>
                        </div>
                    </div>
                    <div className="card mb-4">
                        <div className="card-header text-white bg-primary">
                            <span style={{float:"left"}}>
                                What can be improved in this volunteering activity?
                            </span>
                        </div>
                        <div className="card-body">
                            <textarea className="form-control" id="validationTextarea" placeholder="you're thoughts here" required></textarea>
                        </div>
                    </div>
                    <div className="modal-footer" style={{borderTop:0}}>
                        <button type="button" className="btn btn-danger" style={{float:'right'}}>Reset</button>
                        <button type="button" className="btn btn-primary" style={{float:'right'}}>Submit</button>
                    </div>
                </div>
            </div>
        </React.Fragment>
    )

})

export default Attempted;