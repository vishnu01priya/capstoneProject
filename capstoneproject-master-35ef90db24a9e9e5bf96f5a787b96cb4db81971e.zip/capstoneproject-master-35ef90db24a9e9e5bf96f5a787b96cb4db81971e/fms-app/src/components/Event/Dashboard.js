import React, { useEffect, useState } from 'react';
import axios from 'axios';
import Loading from '../global/Loading';

const Dashboard = React.memo(props => {

    const [dashboardData,setDashboardData] = useState({});
    const [dataFetch, setDataFetch] = useState(false);

    useEffect(() => {
        console.log("role in dashboard "+localStorage.getItem("role"));
            if(localStorage.getItem("role") === "admin" || localStorage.getItem("role") === "pmo") {
                axios("/event/api/v1/dashboard").then((response) => {
                    setDashboardData(response.data);
                    setDataFetch(true);
                },(error) => {
                    console.log(error);
                })
            } else if(localStorage.getItem("role") === "poc") {
                axios({
                    url: '/event/api/v1/pocDashboard',
                    method: 'POST',
                    data: {
                        username: localStorage.getItem("username")
                    }
                  }).then((response) => {
                    setDashboardData(response.data);
                    setDataFetch(true);
                    console.log(response);
                  }, (error) => {
                    console.log(error);
                  });
            }
    },[])


  return (
    <React.Fragment>
        {dataFetch ? (
            <div className="row">
                <div className="col-lg-3 col-md-3 col-sm-3 col-xs-3">
                <div className="card text-white bg-primary mb-3">
                    <div className="card-header">Total Events</div>
                    <div className="card-body">
                        <h5 className="card-title">{dashboardData.totalEvents}</h5>
                    </div>
                </div>
                </div>
                <div className="col-lg-3 col-md-3 col-sm-3 col-xs-3">
                <div className="card text-white bg-secondary mb-3">
                    <div className="card-header">Lives Impacted</div>
                    <div className="card-body">
                        <h5 className="card-title">{dashboardData.livesImpacted}</h5>
                    </div>
                </div>
                </div>
                <div className="col-lg-3 col-md-3 col-sm-3 col-xs-3">
                <div className="card text-white bg-success mb-3">
                    <div className="card-header">Total Volunteers</div>
                    <div className="card-body">
                        <h5 className="card-title">{dashboardData.totalVolunteers}</h5>
                    </div>
                </div>
                </div>
                <div className="col-lg-3 col-md-3 col-sm-3 col-xs-3">
                <div className="card text-white bg-danger mb-3">
                    <div className="card-header">Total Participants</div>
                    <div className="card-body">
                        <h5 className="card-title">{dashboardData.totalParticipants}</h5>
                    </div>
                </div>
                </div>
            </div>
        ) : (
            <Loading />
        )}
    </React.Fragment>
  );
});

export default Dashboard;