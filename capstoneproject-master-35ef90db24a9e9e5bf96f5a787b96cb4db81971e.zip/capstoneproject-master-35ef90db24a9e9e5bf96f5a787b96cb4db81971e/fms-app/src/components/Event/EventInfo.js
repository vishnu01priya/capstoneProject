import React,{ useState,useEffect } from "react";
import axios from 'axios';
import Loading from "../global/Loading";
import { Link } from "react-router-dom";

const EventInfo = React.memo( (props => {
    
    const [eventInfo,setEventInfo] = useState({});
    const [showLoading,setShowLoading] = useState(true);
    const [sendMailStatus,setSendMailStatus] = useState(false);

    useEffect( () => {
        let eventId = props.location.data.eventId;
        const fetchData = async () => {
            const result = await axios('/event/api/v1/findByEventId/'+eventId);
            setEventInfo(result.data);
            setShowLoading(false)
        }
        fetchData();
    },[])

    const sendMail = () => {
        console.log("inside send mail");
        let eventId = props.location.data.eventId;
        setShowLoading(true);
        axios("/email/api/v1/sendEventEmail/"+eventId).then(
            res => {
                console.log("res",res);
                if(res.data == true){
                setSendMailStatus(true);
                }
                setShowLoading(false);
            }
        );
    }

    return(
        <React.Fragment>
            {
                showLoading ? <Loading /> :
                <div>
                <div className="row mb-4">
                    <div className="col-sm-6">
                        <div className="card">
                            <div className="card-body">
                                <h5 className="card-title">E-Mail Reminder!</h5>
                                <p className="card-text">Sit back and relax while the app send emails!</p>
                                <a href="#" className="btn btn-primary" onClick={() => sendMail()} >Send Email</a>
                                &nbsp;{sendMailStatus ? <span className="badge badge-success">Mail Sent!</span>:""}
                            </div>
                        </div>
                    </div>
                    <div className="col-sm-6">
                        <div className="card">
                            <div className="card-body">
                                <h5 className="card-title">Future Implementations</h5>
                                <p className="card-text">This place holder can be used for adding any other actions in future.</p>
                                <a href="#" className="btn btn-primary">Go somewhere</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="row mb-4">
                    <div className="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                        <div className="card">
                            <div className="card-header text-white bg-primary">
                                <span style={{float:"left"}}>ID : {eventInfo.eventId}</span>
                                <span style={{float:"right"}}>Date : {eventInfo.startDate}</span>
                            </div>
                            <div className="card-body">
                                <h5 className="card-title">{eventInfo.name}</h5>
                                <p className="card-text">{eventInfo.description}</p>
                                
                            </div>
                            <div className="card-footer text-muted">
                                <span style={{float:"left"}}>Status : <span className="badge badge-success">{eventInfo.status}</span></span>
                                <span style={{float:"right"}}>Category : {eventInfo.category}</span>
                            </div>
                        </div>
                    </div>
                    <div className="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                        <div className="card">
                            <div className="card-header text-white bg-primary">
                                <span style={{float:"left"}}>Location : {eventInfo.baseLocation}</span>
                                <span style={{float:"right"}}>Council : {eventInfo.councilName}</span>
                            </div>
                            <div className="card-body">
                            <h5 className="card-title">{eventInfo.beneficiaryName}</h5>
                                <p className="card-text">{eventInfo.venueAddress}</p>
                                
                            </div>
                            <div className="card-footer text-muted">
                                <span style={{float:"left"}}>
                                    Feedback : <span className="badge badge-warning">3</span>
                                </span>
                                <span style={{float:"right"}}>
                                    Average Rating : <span className="badge badge-info">4</span>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="row mb-4">
                    <div className="col-lg-4 col-md-4 col-sm-4 col-xs-4">
                        <div className="card text-center">
                            <div className="card-header text-white bg-primary">
                                PARTICIPATED
                            </div>
                            <div className="card-body">
                                <h5 className="card-title">Special title treatment</h5>
                                <p className="card-text">With supporting text below as a natural lead-in to additional content.</p>    
                            </div>
                        </div>
                    </div>
                    <div className="col-lg-4 col-md-4 col-sm-4 col-xs-4">
                        <div className="card text-center">
                            <div className="card-header text-white bg-primary">
                                NOT PARTICIPATED
                            </div>
                            <div className="card-body">
                                <h5 className="card-title">Special title treatment</h5>
                                <p className="card-text">With supporting text below as a natural lead-in to additional content.</p>
                            </div>
                        </div>
                    </div>
                    <div className="col-lg-4 col-md-4 col-sm-4 col-xs-4">
                        <div className="card text-center">
                            <div className="card-header text-white bg-primary">
                                UNREGISTERED
                            </div>
                            <div className="card-body">
                                <h5 className="card-title">Special title treatment</h5>
                                <p className="card-text">With supporting text below as a natural lead-in to additional content.</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="row mb-4">
                    <div className="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                        <div className="card text-center">
                            <div className="card-header text-white bg-primary">
                                STATISTICS
                            </div>
                            <div className="card-body">
                                <table className="table table-sm">
                                    <thead className="thead-light">
                                        <tr>
                                            <th scope="col">Average Rating</th>
                                            <th scope="col">Volunteers</th>
                                            <th scope="col">Volunteering Hours</th>
                                            <th scope="col">Overall Hours</th>
                                            <th scope="col">Travel Hours</th>
                                            <th scope="col">Lives Impacted</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <th scope="row">4</th>
                                            <td>{eventInfo.totalVolunteer}</td>
                                            <td>{eventInfo.totalVolunteerHour}</td>
                                            <td>{eventInfo.overallVolunterHour}</td>
                                            <td>{eventInfo.totalTravelHour}</td>
                                            <td>{eventInfo.livesImpacted}</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <div className="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                        <div className="card text-center">
                            <div className="card-header text-white bg-primary">
                                POC DETAILS
                            </div>
                            <div className="card-body">
                                <table className="table">
                                <thead className="thead-light">
                                    <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Employee ID</th>
                                    <th scope="col">Name</th>
                                    <th scope="col">Contact Number</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <th scope="row">1</th>
                                        <td>{eventInfo.poc.username}</td>
                                        <td>{eventInfo.poc.name}</td>
                                        <td>{eventInfo.poc.mobile}</td>
                                    </tr>
                                </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                </div>
                
            }
        </React.Fragment>
    )

}));

export default EventInfo;