import React, { useState, useEffect } from "react";
import axios from "axios";
import Loading from "../global/Loading";
import { Link } from "react-router-dom";

const ViewEvents = React.memo(props => {

  const [eventList, setEventList] = useState([]);
  const [showLoading, setShowLoading] = useState(true);
  const [sendMailStatus,setSendMailStatus] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      const result = await axios("/event/api/v1/listAll");
      console.log("result",result);
      setEventList(result);
      setShowLoading(false);
    };

    fetchData();
  }, []);

  const sendMail = () => {
    console.log("inside send mail");
    setShowLoading(true);
    axios("/email/api/v1/sendEmail").then(
      res => {
        console.log("res",res);
        if(res.data == true){
          setSendMailStatus(true);
        }
        setShowLoading(false);
      }
    );
  }

  return (
    <React.Fragment>
      { showLoading ?  <Loading /> :
        <div>
          <div className="row mb-4">
            <div className="col-sm-6">
              <div className="card">
                <div className="card-body">
                  <h5 className="card-title">E-Mail Reminder!</h5>
                  <p className="card-text">Sit back and relax while the app send emails!</p>
                  <a href="#" className="btn btn-primary" onClick={() => sendMail()} >Send Email</a>
                  &nbsp;{sendMailStatus ? <span className="badge badge-success">Mail Sent!</span>:""}
                </div>
              </div>
            </div>
            <div className="col-sm-6">
              <div className="card">
                <div className="card-body">
                  <h5 className="card-title">Future Implementations</h5>
                  <p className="card-text">This place holder can be used for adding any other actions in future.</p>
                  <a href="#" className="btn btn-primary">Go somewhere</a>
                </div>
              </div>
            </div>
          </div>
          <div className="card">
            <div className="card-header" style={{ textAlign: "left" }}>
              List of Events
            </div>
            <div className="card-body">
              <div className="table-responsive">
                <table className="table table-sm table-bordered">
                  <thead>
                    <tr>
                      <th scope="col">Event Id</th>
                      <th scope="col">Name</th>
                      <th scope="col">Status</th>
                      <th scope="col">Venue Address</th>
                      <th scope="col">Total Volunteers</th>
                      <th scope="col">Total Volunteer Hours</th>
                      <th scope="col">Total Travel Hours</th>
                    </tr>
                  </thead>
                  <tbody>
                    {eventList.data.map(eventsIns => (
                      <tr key={eventsIns.id}>
                        <th scope="row">
                          <Link
                            to={{
                              pathname: "/event/eventinfo",
                              data: {
                                eventId: eventsIns.eventId
                              }
                            }}
                          >
                            {eventsIns.eventId}
                          </Link>
                        </th>
                        <td>{eventsIns.name}</td>
                        <td>{eventsIns.status}</td>
                        <td>{eventsIns.venueAddress}</td>
                        <td>{eventsIns.totalVolunteer}</td>
                        <td>{eventsIns.totalVolunteerHour}</td>
                        <td>{eventsIns.totalTravelHour}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
    }
    </React.Fragment>
  );
});

export default ViewEvents;
