import React, { useEffect, useState } from 'react';

const Header = React.memo(props => {

  const [loginStatus,setLoginStatus] = useState(false);

  useEffect( () => {

    let token = localStorage.getItem("react-token");
    if(token != undefined) {
      setLoginStatus(true);
    } else {
      token = localStorage.getItem("react-refresh-token");
      if(token != undefined)
        setLoginStatus(true);
    }

  })

  return(
    <React.Fragment>
      <nav className="navbar navbar-expand-sm navbar-dark bg-primary mb-4">
        <div className="container">
          <a className="navbar-brand" href="/dashboard">
            Outreach FMS
          </a>
          <button
            className="navbar-toggler"
            type="button"
            data-toggle="collapse"
            data-target="#mobile-nav"
          >
            <span className="navbar-toggler-icon" />
          </button>
          
          <div className="collapse navbar-collapse" id="mobile-nav">
          {
            localStorage.getItem('role') == 'associate' ? '' :
            <ul className="navbar-nav mr-auto">
              <li className="nav-item">
                <a className="nav-link" href="/dashboard">
                  Dashboards
                </a>
              </li>
              <li className="nav-item">
                <a className="nav-link" href="/event/index">
                  Events
                </a>
              </li>
              <li className="nav-item">
                <a className="nav-link" href="/event/report">
                  Reports
                </a>
              </li>
              <li className="nav-item dropdown">
                <a className="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  Configuration
                </a>
                <div className="dropdown-menu" aria-labelledby="navbarDropdown">
                  <a className="dropdown-item" href="/user/index">User</a>
                  <a className="dropdown-item" href="/feedback/index">Feedback</a>
                </div>
              </li>
            </ul>
          }
            <ul className="navbar-nav ml-auto">
            <li className="nav-item">
                {
                  localStorage.getItem("username") ? <label className="nav-link">Welcome : {localStorage.getItem("username")}</label>  : ""
                }
              </li>
              <li className="nav-item">
                {
                  loginStatus ? <a className="nav-link" href="http://127.0.0.1:8080/auth/realms/fms/protocol/openid-connect/logout?redirect_uri=http://localhost:3000">Logout</a> : <a className="nav-link" href="login.html">Login</a>
                }
              </li>
            </ul>
          </div>
        
        </div>
      </nav>
    </React.Fragment>
  )

});

export default Header;
