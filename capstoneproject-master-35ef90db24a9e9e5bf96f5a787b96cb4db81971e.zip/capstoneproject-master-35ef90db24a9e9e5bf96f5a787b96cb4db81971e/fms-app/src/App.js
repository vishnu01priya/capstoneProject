import React from 'react';
import logo from './logo.svg';
import "bootstrap/dist/css/bootstrap.min.css"
import Header from './components/global/Header';
import Login from './components/Login/Login';
import { Route, Link, BrowserRouter as Router } from 'react-router-dom';
import Dashboard from './components/Event/Dashboard';
import EventIndex from './components/Event/Index';
import EventInfo from './components/Event/EventInfo';
import FeedbackIndex from './components/Feedback/Index';
import UserIndex from './components/User/Index';
import QuestionInfo from './components/Feedback/QuestionInfo';
import Attempt from './components/Feedback/Attempt';
import Report from './components/Event/Report';

function App() {
  return (
    <div className="App">
      <Router>
        <Header />
        <div className="container">
          {
            localStorage.getItem('role') == 'associate' ? 
            <Route exact path="/" component={Attempt}/> : <Route exact path="/" component={Dashboard}/>
          }
          <Route path="/dashboard" component={Dashboard} />
          <Route path="/event/index" component={EventIndex} />
          <Route path="/event/eventinfo" component={EventInfo} />
          <Route path="/event/report" component={Report} />
          <Route path="/feedback/index" component={FeedbackIndex} />
          <Route path="/feedback/questioninfo" component={QuestionInfo} />
          <Route path="/user/index" component={UserIndex} />
        </div>
      </Router>
    </div>
  );
}

export default App;
